/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package a_star_search;

import java.util.PriorityQueue;

/**
 *
 * @author Rayhan
 */
public class temp {
    
    PriorityQueue<Node> priorityQueue;
    public void func()
    {
//        priorityQueue=new PriorityQueue<>(100000, new MyComparator());
//        priorityQueue.add(new Node(null,12));
//        priorityQueue.add(new Node(null,12));
//        priorityQueue.add(new Node(null,12));
//        priorityQueue.add(new Node(null,12));
    }

    
}
